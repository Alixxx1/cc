# Ax-Tool
#Hi. To the 'Ax Tool' Come on, a simple tool that includes several divisions It saves the user time There are tools on penetration (the “hacker”), except for a break from the penetration test (Moral penetration) Recommend using it Thank you
import os
os.sys
from time import sleep as timeout
from core.lzmcore import *

def main():
        banner()
        print "   [01] Entertainment section
        Ax Tool = raw_input("Ax Tool > ")
        
        if Ax Tool == "1" or Ax Tool == "01":
        print "\n    [01] Nmap"
        Entertainment section= raw_input("Ax Tool > ")
        
        if Entertainment section == "01" or Entertainment section == "1":
			nmap()
                        
        else:
			print "\nERROR: Wrong Input"
			timeout(2)
			restart_program()
	
